package boot;

import controller.MyController;
import model.MyModel;
import view.MyAsciiArtMaker;

public class Run {

	public static void main(String[] args) {
		MyAsciiArtMaker win=new MyAsciiArtMaker("ASCII maker", 500, 300);
		MyModel m=new MyModel();
		MyController c =new MyController(win, m);
		
		win.setController(c);
		m.setController(c);
		
		win.start();
	}

}
