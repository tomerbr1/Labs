package controller;

public interface Controller {

	public void display(String fileName);

	public void convert(String fileName);

}