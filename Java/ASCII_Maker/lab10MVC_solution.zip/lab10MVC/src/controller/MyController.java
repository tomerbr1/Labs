package controller;

import model.Model;
import view.View;

public class MyController implements Controller {

	View view;
	Model model;
	
	public MyController(View view,Model model) {
		this.view=view;
		this.model=model;
	}
	
	@Override
	public void display(String fileName){
		view.display(fileName);
	}
	
	@Override
	public void convert(String fileName){
		model.convert(fileName);
	}
}
