package model;

public interface Model {
	public void convert(String fileName);
}
