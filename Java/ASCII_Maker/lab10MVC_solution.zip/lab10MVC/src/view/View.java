package view;

public interface View {

	public void display(String fileName);
	public void start();
}
